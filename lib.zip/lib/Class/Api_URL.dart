// ignore_for_file: file_names

class ApiConstants {
  static const String baseUrl = 'https://apps.iitism.ac.in/api/';
  static const String baseUrllogin = 'apps.iitism.ac.in';
  static const String endpointotp = '/api/Admin_sendOTP';
  static const String endpointotpnew = '/api/Password_verify';
  static const String endpointverify = '/api/Admin_verifyOTP';
}

// class ApiConstants {
//   static const String baseUrl =
//       'https://maaalankarjewellers.com/ismapinew/api/';
//   static const String baseUrllogin = 'www.maaalankarjewellers.com';
//   static const String endpointotp = '/ismapinew/api/Admin_sendOTP';
//   static const String endpointverify = '/ismapinew/api/Admin_verifyOTP';
// }
// class ApiConstants {
//   static const String baseUrl = 'https://bazar11.com/ismapinew/api/';
//   static const String baseUrllogin = 'www.bazar11.com';
//    static const String endpointotpnew = '/ismapinew/api/Password_verify';
//   static const String endpointotp = '/ismapinew/api/Admin_sendOTP';
//   static const String endpointverify = '/ismapinew/api/Admin_verifyOTP';
// }
