

// class User {
//   final int? id;
//   final String? name;
//   final Uint8List? fingerprint;
//   final String? fingerprint_id;

//   User({required this.id, this.name, this.fingerprint, this.fingerprint_id});

//   factory User.fromMap(Map<String, dynamic> map) {
//     return User(
//       id: map['id'],
//       name: map['name'],
//       fingerprint: map['fingerprint'],
//       fingerprint_id: map['fingerprint_id'],
//     );
//   }
// }
